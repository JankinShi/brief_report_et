# 2019-nCoV
新冠肺炎大屏数据分析

发布网址：

 http://49.234.72.130:8111/index 

# 内容

1. 各国确诊患者排名
2. 中国确诊在院患者、确诊治愈、确诊死亡、现有疑似占比分析
3. 国内各省确诊数地图

# 数据来源

网易实时数据接口： https://c.m.163.com/ug/api/wuhan/app/index/feiyan-data-list 

# 效果图

![image-20200226132733705](C:\Users\SYT\AppData\Roaming\Typora\typora-user-images\image-20200226132733705.png)



