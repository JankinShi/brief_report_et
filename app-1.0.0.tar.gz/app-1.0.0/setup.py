# coding:utf8
from setuptools import setup,find_packages
import os

cwd = os.getcwd()

setup (
    name='app',   # 应用名
    version='1.0.0',  # 版本号
    packages=find_packages(),  # 打包你的所有包及子包
    # packages=['app'],
    description="ertong brief report",
    author="jankin",
    author_email="",
    include_package_data=True,    # 启用清单文件MANIFEST.in,可将非python文件一同打包成package
    # exclude_package_date={'app':['.gitignore']}, # 只排除”app”包下的所有”.gitignore”文件
    exclude_package_date={'':['.gitignore']}, # 排除所有”.gitignore”文件
    zip_safe=False,

    # 依赖列表是必须的
    install_requires=[  # 依赖列表
        'pymssql==2.1.4',
        'sqlparse==0.2.4',
    ],
    dependency_links=[  # 依赖包下载可选的路径，可以是本地路径
    cwd+'\\user_packages'
    ]
)